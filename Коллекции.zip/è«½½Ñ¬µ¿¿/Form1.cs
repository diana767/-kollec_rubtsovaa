﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Коллекции
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Hashtable phbook = new Hashtable();
        Hashtable phbook1 = new Hashtable();

        private void button1_Click(object sender, EventArgs e)
        {
            
                if (textBox2.Text == "" && textBox1.Text == "")
                {
                    MessageBox.Show("Поля пустые, заполните поля");
                }
                else
                if (textBox2.Text == "")
                {
                    MessageBox.Show("Поле номер пустое");
                }
                else
                if (textBox1.Text == "")
                {
                    MessageBox.Show("Поле фамилия пустое");
                }
            else
                for (int i = 0; i < textBox1.Text.Length; i++)
                {
                    if (!char.IsLetter(textBox1.Text[i]))
                    {
                        MessageBox.Show("Неккоректно введена фамилия");
                        break;
                    }
                    
                }
            for (int i = 0; i < textBox2.Text.Length; i++)
            {
                if (char.IsLetter(textBox2.Text[i]))
                {
                    MessageBox.Show("номер должен состоять только из цифр");
                    break;
                }

            }
           
                try
                {
                    {
                        listBox1.Items.Add($"Tel: {textBox2.Text}\t Фамилия: {textBox1.Text}");
                        phbook.Add(textBox2.Text, textBox1.Text);
                        phbook1.Add(textBox1.Text, textBox2.Text);
                    }
                }
                catch { MessageBox.Show("Элемент уже существет в списке"); }
            
            
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
       
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            }
            catch { MessageBox.Show("Поле не выбрано"); }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (phbook.ContainsKey(textBox4.Text) == true)
            {
                string tel = Convert.ToString(phbook[$"{textBox4.Text}"]);
                MessageBox.Show($"Фамилия: {tel}");
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (phbook1.ContainsKey(textBox3.Text)==true)
            {
                string fam = Convert.ToString(phbook1[$"{textBox3.Text}"]);
                MessageBox.Show($"Номер: {fam}");
            }
        }

     
    }
}
